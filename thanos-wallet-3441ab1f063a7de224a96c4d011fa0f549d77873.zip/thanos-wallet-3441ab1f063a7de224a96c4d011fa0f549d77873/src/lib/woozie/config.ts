export const USE_LOCATION_HASH_AS_URL = true;
