declare module "@taquito/local-forging/dist/lib/michelson/codec";
declare module "@taquito/local-forging/dist/lib/uint8array-consumer";
