declare module "bs58check";
