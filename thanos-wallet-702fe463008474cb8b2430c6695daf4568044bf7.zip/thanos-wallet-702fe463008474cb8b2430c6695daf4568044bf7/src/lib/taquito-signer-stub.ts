export async function importKey() {
  throw new Error("This method is unloaded from @taquito/taquito");
}
